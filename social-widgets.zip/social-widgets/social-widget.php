<?php
/*
Plugin Name: Social Widgets
Description: Adds floating social media widgets to your website with customization options.
Version: 1.0
Author: Faisal Humayun
Author URI: https://progressivesofts.com
License: GPLv2 or later
Text Domain: social-widgets
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Load text domain for translations
function social_widgets_load_textdomain() {
    load_plugin_textdomain('social-widgets', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'social_widgets_load_textdomain');

// Enqueue styles and scripts
function social_widgets_enqueue_scripts() {
    // Enqueue CSS
    wp_enqueue_style('social-widgets-style', plugin_dir_url(__FILE__) . 'css/style.css');

    // Enqueue JavaScript
    wp_enqueue_script('social-widgets-script', plugin_dir_url(__FILE__) . 'js/script.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'social_widgets_enqueue_scripts');

// Create settings menu in WP Admin
function social_widgets_menu() {
    add_menu_page(
        __('Social Widgets', 'social-widgets'), // Page title
        __('Social Widgets', 'social-widgets'), // Menu title
        'manage_options',  // Capability
        'social-widgets', // Menu slug
        'social_widgets_settings_page' // Callback function
    );
}
add_action('admin_menu', 'social_widgets_menu');

// Register settings
function social_widgets_register_settings() {
    register_setting('social_widgets_settings', 'social_widgets_options', 'social_widgets_sanitize_options');
}
add_action('admin_init', 'social_widgets_register_settings');

// Sanitize and validate input
function social_widgets_sanitize_options($input) {
    $input['whatsapp_phone_number'] = sanitize_text_field($input['whatsapp_phone_number']);
    $input['whatsapp_button_position'] = in_array($input['whatsapp_button_position'], ['right', 'left']) ? $input['whatsapp_button_position'] : 'right';
    $input['whatsapp_button_style'] = in_array($input['whatsapp_button_style'], ['round', 'box']) ? $input['whatsapp_button_style'] : 'round';
    $input['whatsapp_message_text'] = sanitize_text_field($input['whatsapp_message_text']);
    $input['facebook_url'] = esc_url_raw($input['facebook_url']);
    $input['instagram_url'] = esc_url_raw($input['instagram_url']);
    $input['twitter_url'] = esc_url_raw($input['twitter_url']);
    return $input;
}

// Settings page HTML
function social_widgets_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $options = get_option('social_widgets_options', [
        'whatsapp_phone_number' => '',
        'whatsapp_button_position' => 'right',
        'whatsapp_button_style' => 'round',
        'whatsapp_message_text' => __('Hello! I have a question.', 'social-widgets'),
        'facebook_url' => '',
        'instagram_url' => '',
        'twitter_url' => '',
    ]);
    ?>
    <div class="wrap">
        <h1><?php _e('Social Widgets Settings', 'social-widgets'); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields('social_widgets_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="whatsapp_phone_number"><?php _e('WhatsApp Phone Number:', 'social-widgets'); ?></label></th>
                    <td>
                        <input type="text" name="social_widgets_options[whatsapp_phone_number]" id="whatsapp_phone_number" value="<?php echo esc_attr($options['whatsapp_phone_number']); ?>" required>
                        <p class="description"><?php _e('Enter your WhatsApp number in international format (e.g., 1234567890).', 'social-widgets'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="whatsapp_button_position"><?php _e('Widget Position:', 'social-widgets'); ?></label></th>
                    <td>
                        <select name="social_widgets_options[whatsapp_button_position]" id="whatsapp_button_position">
                            <option value="right" <?php selected($options['whatsapp_button_position'], 'right'); ?>><?php _e('Bottom Right', 'social-widgets'); ?></option>
                            <option value="left" <?php selected($options['whatsapp_button_position'], 'left'); ?>><?php _e('Bottom Left', 'social-widgets'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="whatsapp_button_style"><?php _e('Widget Style:', 'social-widgets'); ?></label></th>
                    <td>
                        <select name="social_widgets_options[whatsapp_button_style]" id="whatsapp_button_style">
                            <option value="round" <?php selected($options['whatsapp_button_style'], 'round'); ?>><?php _e('Round', 'social-widgets'); ?></option>
                            <option value="box" <?php selected($options['whatsapp_button_style'], 'box'); ?>><?php _e('Box', 'social-widgets'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="whatsapp_message_text"><?php _e('WhatsApp Message:', 'social-widgets'); ?></label></th>
                    <td>
                        <input type="text" name="social_widgets_options[whatsapp_message_text]" id="whatsapp_message_text" value="<?php echo esc_attr($options['whatsapp_message_text']); ?>">
                        <p class="description"><?php _e('Enter the default message to be sent when the widget is clicked.', 'social-widgets'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="facebook_url"><?php _e('Facebook URL:', 'social-widgets'); ?></label></th>
                    <td>
                        <input type="url" name="social_widgets_options[facebook_url]" id="facebook_url" value="<?php echo esc_attr($options['facebook_url']); ?>">
                        <p class="description"><?php _e('Enter your Facebook profile or page URL.', 'social-widgets'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="instagram_url"><?php _e('Instagram URL:', 'social-widgets'); ?></label></th>
                    <td>
                        <input type="url" name="social_widgets_options[instagram_url]" id="instagram_url" value="<?php echo esc_attr($options['instagram_url']); ?>">
                        <p class="description"><?php _e('Enter your Instagram profile URL.', 'social-widgets'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="twitter_url"><?php _e('Twitter URL:', 'social-widgets'); ?></label></th>
                    <td>
                        <input type="url" name="social_widgets_options[twitter_url]" id="twitter_url" value="<?php echo esc_attr($options['twitter_url']); ?>">
                        <p class="description"><?php _e('Enter your Twitter profile URL.', 'social-widgets'); ?></p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Display social media widgets
function social_widgets_display() {
    $options = get_option('social_widgets_options', [
        'whatsapp_phone_number' => '',
        'whatsapp_button_position' => 'right',
        'whatsapp_button_style' => 'round',
        'whatsapp_message_text' => __('Hello! I have a question.', 'social-widgets'),
        'facebook_url' => '',
        'instagram_url' => '',
        'twitter_url' => '',
    ]);

    $phone = $options['whatsapp_phone_number'];
    $position = $options['whatsapp_button_position'];
    $style = $options['whatsapp_button_style'];
    $message = $options['whatsapp_message_text'];
    $facebook_url = $options['facebook_url'];
    $instagram_url = $options['instagram_url'];
    $twitter_url = $options['twitter_url'];

    ?>
    <div class="social-widgets <?php echo esc_attr($position); ?>">
        <?php if ($phone) : ?>
            <a href="https://wa.me/<?php echo esc_attr($phone); ?>?text=<?php echo urlencode($message); ?>" target="_blank" class="social-widget whatsapp <?php echo esc_attr($style); ?>">
                <img src="<?php echo plugin_dir_url(__FILE__); ?>assets/icons/whatsapp-icon.webp" alt="WhatsApp">
            </a>
        <?php endif; ?>
        <?php if ($facebook_url) : ?>
            <a href="<?php echo esc_url($facebook_url); ?>" target="_blank" class="social-widget facebook <?php echo esc_attr($style); ?>">
                <img src="<?php echo plugin_dir_url(__FILE__); ?>assets/icons/facebook-icon.webp" alt="Facebook">
            </a>
        <?php endif; ?>
        <?php if ($instagram_url) : ?>
            <a href="<?php echo esc_url($instagram_url); ?>" target="_blank" class="social-widget instagram <?php echo esc_attr($style); ?>">
                <img src="<?php echo plugin_dir_url(__FILE__); ?>assets/icons/instagram-icon.webp" alt="Instagram">
            </a>
        <?php endif; ?>
        <?php if ($twitter_url) : ?>
            <a href="<?php echo esc_url($twitter_url); ?>" target="_blank" class="social-widget twitter <?php echo esc_attr($style); ?>">
                <img src="<?php echo plugin_dir_url(__FILE__); ?>assets/icons/twitter-icon.webp" alt="Twitter">
            </a>
        <?php endif; ?>
    </div>
    <?php
}
add_action('wp_footer', 'social_widgets_display');