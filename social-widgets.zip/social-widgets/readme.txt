=== Social Widgets ===
Contributors: faisal44
Tags: social media, widgets, whatsapp, facebook, instagram, twitter
Requires at least: 5.6
Tested up to: 6.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin to add floating social media widgets to your website.

== Description ==

This plugin allows you to add floating social media widgets (WhatsApp, Facebook, Instagram, Twitter) to your website. You can customize the position, style, and links for each widget.

== Installation ==

1. Upload the `social-widgets` folder to the `wp-content/plugins/` directory.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Go to **Social Widgets** in the admin menu to configure the settings.

== Screenshots ==

1. Admin Settings Page
2. Frontend Widgets (Round Style)
3. Frontend Widgets (Box Style)

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.0 =
Initial release.