jQuery(document).ready(function ($) {
    // Smooth scroll animation for widget links
    $('.social-widget a').on('click', function (e) {
        if (this.hash !== '') {
            e.preventDefault();

            const hash = this.hash;

            // Smooth scroll to the target element
            $('html, body').animate(
                {
                    scrollTop: $(hash).offset().top,
                },
                800, // Animation duration in milliseconds
                function () {
                    // Add hash (#) to URL after scroll
                    window.location.hash = hash;
                }
            );
        }
    });

    // Dynamic hover effects for widgets
    $('.social-widget').hover(
        function () {
            // Add hover class on mouse enter
            $(this).addClass('widget-hover');
        },
        function () {
            // Remove hover class on mouse leave
            $(this).removeClass('widget-hover');
        }
    );
});